<?php

namespace Civi\Api4\Action\Afform;

/**
 * @inheritDoc
 * @package Civi\Api4\Action\Afform
 */
class Create extends \Civi\Api4\Generic\BasicCreateAction {

  use \Civi\Api4\Utils\AfformSaveTrait;

}
