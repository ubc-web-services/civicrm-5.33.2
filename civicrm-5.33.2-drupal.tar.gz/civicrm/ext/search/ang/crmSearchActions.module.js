(function(angular, $, _) {
  "use strict";

  // Declare module
  angular.module('crmSearchActions', CRM.angRequires('crmSearchActions'));

})(angular, CRM.$, CRM._);
