<?php
// Search kit - base module with utilities & services.
return [
  'js' => [
    'ang/crmSearchKit.module.js',
    'ang/crmSearchKit/*.js',
    'ang/crmSearchKit/*/*.js',
  ],
  'partials' => [
    'ang/crmSearchKit',
  ],
  'basePages' => [],
  'requires' => [],
];
