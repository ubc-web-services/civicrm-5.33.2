# CiviCRM Search Kit

A core extension to create complex searches, reports & smart groups.

## Usage

Once enabled, navigate to **Search > Search Kit** in the menu.

## Development

https://chat.civicrm.org/civicrm/channels/search-improvements

https://lab.civicrm.org/dev/report/-/issues
